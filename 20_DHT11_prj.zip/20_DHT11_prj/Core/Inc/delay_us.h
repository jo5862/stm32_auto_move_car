/*
 * delay_us.h
 *
 *  Created on: Jan 17, 2025
 *      Author: wlstn
 */

#ifndef INC_DELAY_US_H_
#define INC_DELAY_US_H_

#include "main.h"

#include "stdio.h"
#include "stdbool.h"
#include "stdint.h"
#include "tim.h"

#include "string.h"



void delay_us(uint16_t us);

#endif /* INC_DELAY_US_H_ */
